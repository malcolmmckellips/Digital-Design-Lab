var struct_i2_c___o_p_e_n___s_t_r_u_c_t =
[
    [ "clhr", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a21fe116060fe1e7dcefef7e0114b18bd", null ],
    [ "enable", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#ac842b6c1dcb3b1f11b611620199dc55c", null ],
    [ "freq", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#aacfad457f5366fa9265eb0a89e43f23b", null ],
    [ "master", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a076a973bb9631a8e8a5fe1452f01f0bc", null ],
    [ "refFreq", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a3b647a722e160769390ac1967b22b318", null ],
    [ "scl_route_enable", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a75ec6c06c611053187333c8c6eb988b1", null ],
    [ "scl_route_location", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#a8bed4388381017a85bfbffe1a349c821", null ],
    [ "sda_route_enable", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#aa0e258b5a380b3af5472620191397bd0", null ],
    [ "sda_route_location", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html#ac084808e76dc5b624fa8da786a64ad16", null ]
];