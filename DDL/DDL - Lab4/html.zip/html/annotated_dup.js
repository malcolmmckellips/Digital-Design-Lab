var annotated_dup =
[
    [ "APP_LETIMER_PWM_TypeDef", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def" ],
    [ "I2C_IO_STRUCT", "struct_i2_c___i_o___s_t_r_u_c_t.html", "struct_i2_c___i_o___s_t_r_u_c_t" ],
    [ "I2C_OPEN_STRUCT", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html", "struct_i2_c___o_p_e_n___s_t_r_u_c_t" ],
    [ "I2C_PAYLOAD", "struct_i2_c___p_a_y_l_o_a_d.html", "struct_i2_c___p_a_y_l_o_a_d" ]
];