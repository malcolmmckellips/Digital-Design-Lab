var sleep__routines_8c =
[
    [ "current_block_energy_mode", "sleep__routines_8c.html#a6543cf1ae0de352b82e80ec95be89727", null ],
    [ "enter_sleep", "sleep__routines_8c.html#a38dae68379e12eee7b465eac207d9e27", null ],
    [ "sleep_block_mode", "sleep__routines_8c.html#ad3bf3466d014f1556634f36fa438169d", null ],
    [ "sleep_open", "sleep__routines_8c.html#af7584e5af42c7017fb1236d686033a38", null ],
    [ "sleep_unblock_mode", "sleep__routines_8c.html#aac09e562117ae75c110cf084ddf66755", null ]
];