var struct_i2_c___i_o___s_t_r_u_c_t =
[
    [ "scl_pin", "struct_i2_c___i_o___s_t_r_u_c_t.html#a4b65cac9460d38ccb4baddcd712e6cf3", null ],
    [ "scl_port", "struct_i2_c___i_o___s_t_r_u_c_t.html#a205f807e52adc509949590b90a1945aa", null ],
    [ "sda_pin", "struct_i2_c___i_o___s_t_r_u_c_t.html#ad1eb913dcddbfee2fc327ef7bbfb88aa", null ],
    [ "sda_port", "struct_i2_c___i_o___s_t_r_u_c_t.html#a04deed67cfd26a5d28c70ca1804101ed", null ]
];