var searchData=
[
  ['scheduler_2ec_30',['scheduler.c',['../scheduler_8c.html',1,'']]],
  ['sleep_5froutines_2ec_31',['sleep_routines.c',['../sleep__routines_8c.html',1,'']]]
];
