var em__system_8c =
[
    [ "SYSTEM_ChipRevisionGet", "group___s_y_s_t_e_m.html#ga6470ed38937ffd0b8b509334c5add7dd", null ],
    [ "SYSTEM_GetCalibrationValue", "group___s_y_s_t_e_m.html#ga84a2becba34bea4a4d718d4dfe14c4db", null ]
];