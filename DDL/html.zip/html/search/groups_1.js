var searchData=
[
  ['core_325',['CORE',['../group___c_o_r_e.html',1,'']]]
];
