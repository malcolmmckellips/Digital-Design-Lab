var retargetio_8c =
[
    [ "RETARGET_ReadChar", "group___retarget_io.html#ga5af724185f484056b02b42f4ab184bfb", null ],
    [ "RETARGET_WriteChar", "group___retarget_io.html#ga856ae0b788dccadc2c83a6e67409be5f", null ]
];