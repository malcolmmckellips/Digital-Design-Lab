var files_dup =
[
    [ "CMSIS", "dir_e7fa9f9ff84ec6f18f923fb2418bfd4b.html", "dir_e7fa9f9ff84ec6f18f923fb2418bfd4b" ],
    [ "emlib", "dir_b87c9fa9320234f602b7b6764d52d08c.html", "dir_b87c9fa9320234f602b7b6764d52d08c" ],
    [ "serial", "dir_4338eb8cf13125ed00e5eeb13fd9192c.html", "dir_4338eb8cf13125ed00e5eeb13fd9192c" ],
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ]
];