var system__efm32pg12b_8c =
[
    [ "EFM32_HFRCO_MAX_FREQ", "system__efm32pg12b_8c.html#acf415d3ffe9ce1a46bef43fb0953c9ea", null ],
    [ "EFM32_HFRCO_STARTUP_FREQ", "system__efm32pg12b_8c.html#a34229077fe53cb40cf87f9310c7f5601", null ],
    [ "EFM32_HFXO_FREQ", "system__efm32pg12b_8c.html#acb2de58226beebaf4830db62d7b6c1d6", null ],
    [ "EFM32_LFRCO_FREQ", "system__efm32pg12b_8c.html#a16a9bb92649e0f2503f1565bf56e2afc", null ],
    [ "EFM32_LFXO_FREQ", "system__efm32pg12b_8c.html#a27d1136b2fa0bc83ea108d11cd29c502", null ],
    [ "EFM32_ULFRCO_FREQ", "system__efm32pg12b_8c.html#a747f64e814730ee6c0fa0483ef475a87", null ],
    [ "SystemCoreClockGet", "system__efm32pg12b_8c.html#af2e6aa1120f0e55e38c83d8387625d16", null ],
    [ "SystemHFClockGet", "system__efm32pg12b_8c.html#ab5991f4c3faeaed3b4f20d5ab515f1f2", null ],
    [ "SystemHFXOClockGet", "system__efm32pg12b_8c.html#aef32887eb9b08a5dd7db73c35ca7c747", null ],
    [ "SystemHFXOClockSet", "system__efm32pg12b_8c.html#ae8a3b3b223a7d08bf9e4d86a259f4e14", null ],
    [ "SystemInit", "system__efm32pg12b_8c.html#a93f514700ccf00d08dbdcff7f1224eb2", null ],
    [ "SystemLFRCOClockGet", "system__efm32pg12b_8c.html#a477d1670608b8ca76108b6e21c1124eb", null ],
    [ "SystemLFXOClockGet", "system__efm32pg12b_8c.html#a186aefb7bb200c8fda0fc0a4d4b2aa14", null ],
    [ "SystemLFXOClockSet", "system__efm32pg12b_8c.html#ace8c3b705bdbdc9172fbc7f2415dfd8b", null ],
    [ "SystemMaxCoreClockGet", "system__efm32pg12b_8c.html#a64cc4ea6124c6503b120933d91edf1a0", null ],
    [ "SystemULFRCOClockGet", "system__efm32pg12b_8c.html#a88eecfafda55942454a9e10912b3f224", null ],
    [ "SystemCoreClock", "system__efm32pg12b_8c.html#aa3cd3e43291e81e795d642b79b6088e6", null ],
    [ "SystemHfrcoFreq", "system__efm32pg12b_8c.html#a019e34c770ed2855a9ce73be796f33d5", null ]
];