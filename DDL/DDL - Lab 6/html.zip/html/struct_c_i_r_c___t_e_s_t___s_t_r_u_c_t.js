var struct_c_i_r_c___t_e_s_t___s_t_r_u_c_t =
[
    [ "result_str", "struct_c_i_r_c___t_e_s_t___s_t_r_u_c_t.html#a176185fbaff05189040f55ff674a4116", null ],
    [ "test_str", "struct_c_i_r_c___t_e_s_t___s_t_r_u_c_t.html#a87c79d45e89ac1beeeff9f5025eaa9f3", null ]
];