var files_dup =
[
    [ "Header_files", "dir_2836a15cb4934d899348251a796bed78.html", "dir_2836a15cb4934d899348251a796bed78" ],
    [ "Source_files", "dir_ef7a21e399fbc934d4c61a81009626dc.html", "dir_ef7a21e399fbc934d4c61a81009626dc" ],
    [ "main.c", "main_8c.html", "main_8c" ]
];