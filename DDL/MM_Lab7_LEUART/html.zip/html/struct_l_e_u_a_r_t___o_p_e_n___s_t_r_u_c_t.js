var struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t =
[
    [ "baudrate", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#ac4f06ea26ed6bd7ae83b92d64ac10b78", null ],
    [ "databits", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#aefdd5595ffda9f304d633b9028a0c56f", null ],
    [ "enable", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#a98e5c02553709fae73fcce68e351cf73", null ],
    [ "parity", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#abcd3df8a64e16cdcd6941686948be516", null ],
    [ "refFreq", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#a3b647a722e160769390ac1967b22b318", null ],
    [ "rx_done_evt", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#a881448b06b92f194080ed49319e9d161", null ],
    [ "rx_en", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#a7b29f2c3194b65d27115206a3828a2f3", null ],
    [ "rx_loc", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#a9965f3a0dd70eab8e6b7280101d1ec70", null ],
    [ "rx_pin_en", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#a04c4a8f2196169117128948838777ff2", null ],
    [ "rxblocken", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#ad10c495d5e0c611eb39a425930460be6", null ],
    [ "sfubrx", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#a47a451a11da7e822b0712c061ec4e760", null ],
    [ "sigframe", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#ae86530cdfd37c2ce4a1c17b4a57224e7", null ],
    [ "sigframe_en", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#a4677535f1ee393bbf6f9bec4945d1270", null ],
    [ "startframe", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#a433cdff1361fd93f2b12aa78cd16afc1", null ],
    [ "startframe_en", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#a99cb14484eab0ced3f7a1c7ee094559e", null ],
    [ "stopbits", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#a376381d7f3f691f29e7aba7b59994cf5", null ],
    [ "tx_done_evt", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#afa4290eee3a9186c8f46cf441bf32532", null ],
    [ "tx_en", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#ac06b9e6080eb16695fcf0c39cd781103", null ],
    [ "tx_loc", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#a671d98e20a8dc79626b263b07e9942fd", null ],
    [ "tx_pin_en", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html#acd9c8109ad8e0f0679fbe423124d8748", null ]
];