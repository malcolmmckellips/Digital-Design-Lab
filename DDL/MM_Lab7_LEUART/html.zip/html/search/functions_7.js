var searchData=
[
  ['remove_5fscheduled_5fevent_141',['remove_scheduled_event',['../scheduler_8c.html#a89d9fd534ca49cadaeebe2048f2f6294',1,'scheduler.c']]]
];
