var searchData=
[
  ['circular_5fbuff_5ftest_109',['circular_buff_test',['../ble_8c.html#a16af821940031d2983eae1dadf880b85',1,'ble.c']]],
  ['cmu_5fopen_110',['cmu_open',['../cmu_8c.html#a0bf9288af36bde6e21cc7c79382fff11',1,'cmu.c']]],
  ['current_5fblock_5fenergy_5fmode_111',['current_block_energy_mode',['../sleep__routines_8c.html#a6543cf1ae0de352b82e80ec95be89727',1,'sleep_routines.c']]]
];
