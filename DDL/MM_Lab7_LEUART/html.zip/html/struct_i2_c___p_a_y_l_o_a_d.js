var struct_i2_c___p_a_y_l_o_a_d =
[
    [ "bytes", "struct_i2_c___p_a_y_l_o_a_d.html#accacac85be505b95d6c86ab1d7103e47", null ],
    [ "data_buffer", "struct_i2_c___p_a_y_l_o_a_d.html#ac47cb79e488248f5ac98cc2dca859c0d", null ],
    [ "device_address", "struct_i2_c___p_a_y_l_o_a_d.html#a5e961d126e4339cdfa5a69e8ad877a46", null ],
    [ "i2c", "struct_i2_c___p_a_y_l_o_a_d.html#a1339bae9a0e94d6488c45da78d312219", null ],
    [ "read_or_write", "struct_i2_c___p_a_y_l_o_a_d.html#a61102d839ee4d761adecac07480be792", null ],
    [ "register_address", "struct_i2_c___p_a_y_l_o_a_d.html#a4d1df185d901b0849de48faea1d80214", null ],
    [ "state", "struct_i2_c___p_a_y_l_o_a_d.html#a2845385f55e3956c322c42a282403b61", null ]
];