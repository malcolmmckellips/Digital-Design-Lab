var annotated_dup =
[
    [ "APP_LETIMER_PWM_TypeDef", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def.html", "struct_a_p_p___l_e_t_i_m_e_r___p_w_m___type_def" ],
    [ "BLE_CIRCULAR_BUF", "struct_b_l_e___c_i_r_c_u_l_a_r___b_u_f.html", "struct_b_l_e___c_i_r_c_u_l_a_r___b_u_f" ],
    [ "CIRC_TEST_STRUCT", "struct_c_i_r_c___t_e_s_t___s_t_r_u_c_t.html", "struct_c_i_r_c___t_e_s_t___s_t_r_u_c_t" ],
    [ "I2C_IO_STRUCT", "struct_i2_c___i_o___s_t_r_u_c_t.html", "struct_i2_c___i_o___s_t_r_u_c_t" ],
    [ "I2C_OPEN_STRUCT", "struct_i2_c___o_p_e_n___s_t_r_u_c_t.html", "struct_i2_c___o_p_e_n___s_t_r_u_c_t" ],
    [ "I2C_PAYLOAD", "struct_i2_c___p_a_y_l_o_a_d.html", "struct_i2_c___p_a_y_l_o_a_d" ],
    [ "LEUART_OPEN_STRUCT", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t.html", "struct_l_e_u_a_r_t___o_p_e_n___s_t_r_u_c_t" ],
    [ "LEUART_PAYLOAD_STRUCT", "struct_l_e_u_a_r_t___p_a_y_l_o_a_d___s_t_r_u_c_t.html", "struct_l_e_u_a_r_t___p_a_y_l_o_a_d___s_t_r_u_c_t" ],
    [ "LEUART_RX_PAYLOAD_STRUCT", "struct_l_e_u_a_r_t___r_x___p_a_y_l_o_a_d___s_t_r_u_c_t.html", "struct_l_e_u_a_r_t___r_x___p_a_y_l_o_a_d___s_t_r_u_c_t" ]
];